#!/bin/bash
# Dummy shell script that just echoes back all arguments.
echo "$*"
