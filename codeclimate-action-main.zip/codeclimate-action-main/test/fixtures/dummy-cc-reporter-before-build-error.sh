#!/bin/bash
# Dummy shell script exits with a non-zero code.
exit 69
